# Category Globe — portable network globe

An interactive 3D globe (Three.js) that floats labelled **category tiles** in orbit
and draws **shipping arcs** from a hub city to a set of destinations. Tiles are
clickable and route to a page of your choosing.

Originally built for ASTSPARES; this is a self-contained copy for reuse.

---

## 1. Dependencies

```bash
npm i three
```

That's the only runtime dependency (built against `three@^0.184`). No Tailwind
needed — the overlay UI uses inline styles and the globe is a `<canvas>`.

Assumes a **Next.js App Router** project with the `@/*` path alias (the default
`"paths": { "@/*": ["./*"] }` in `tsconfig.json`). If your alias differs, fix the
two imports in `components/NetworkGlobe.tsx`.

## 2. Files & where they go

```
components/CategoryGlobe.jsx   → the renderer (Three.js; ~600 lines, untyped JSX)
components/NetworkGlobe.tsx    → client boundary + wiring (edit this to rebrand)
lib/network.ts                 → ShippingDestination type + the destinations list
public/world.jpg               → REQUIRED 2-tone map texture (see notes)
app/network/page.example.tsx   → example page (rename to page.tsx & adapt data)
```

Copy them into the matching folders of your app. Rename `page.example.tsx` to
`app/network/page.tsx` (or wire `<NetworkGlobe />` into any page you like).

## 3. Quick start

```tsx
// app/network/page.tsx
import NetworkGlobe, { type GlobeFamily } from '@/components/NetworkGlobe';

export default function Page() {
  const categories: GlobeFamily[] = [
    { id: 'valves', slug: 'valves', name: 'Valves', code: 'VL',
      route: '/products/valves/', color: '#2FC75A' },
    { id: 'gaskets', slug: 'gaskets', name: 'Gaskets', code: 'GK',
      route: '/products/gaskets/', color: '#E8742F' },
    // ...
  ];
  return <NetworkGlobe categories={categories} />;
}
```

The globe fills its container; the page renders it edge-to-edge. If you want it
full-screen, give the parent `position: relative` / a viewport height — the
renderer mounts an `absolute; inset:0` canvas.

---

## Props (the contract)

`NetworkGlobe` is a thin wrapper. The renderer (`CategoryGlobe`) takes:

| prop             | type                                             | notes |
|------------------|--------------------------------------------------|-------|
| `categories`     | `GlobeFamily[]`                                  | the tiles |
| `destinations`   | `ShippingDestination[]`                          | arc endpoints |
| `hub`            | `{ name, lat, lon }`                             | arc origin + marker |
| `mapSrc`         | `string`                                         | path to the map texture (`/world.jpg`) |
| `codePrefix`     | `string` (default `'AST-'`)                      | shown on each tile as `<prefix><code>` |
| `onCategoryClick`| `(c: GlobeFamily) => void`                       | tile click handler |

```ts
interface GlobeFamily {
  id: string;
  slug: string;
  name: string;        // tile title (uppercased on the tile)
  code?: string;       // tile sub-label, shown as `<codePrefix><code>`
  blurb?: string;
  route: string;       // where a click should go
  color?: string;      // tile fill colour (hex). Falls back to a palette.
  glyph?: string;      // optional; inferred from the name if absent
}

interface ShippingDestination {
  name: string;
  lat: number;
  lng: number;         // the renderer reads lon ?? lng, so `lng` is fine
  serviceable: boolean;// true → green arc/dot, false → orange (planned)
}
```

`NetworkGlobe` currently hard-codes `destinations`, `hub`, and `mapSrc` and wires
`onCategoryClick` to `router.push(c.route)`. Edit that file to rebrand (below).

---

## Rebranding checklist for a new app

1. **Hub** — in `components/NetworkGlobe.tsx`, change
   `hub={{ name: 'Mumbai', lat: 19.07, lon: 72.87 }}`.
2. **Destinations** — replace the list in `lib/network.ts` (set `serviceable`
   per city → green vs orange). Update the heading count automatically; it reads
   the array length.
3. **Tile prefix** — pass `codePrefix="TB-"` (or `""` for none) from
   `NetworkGlobe.tsx`:
   `<CategoryGlobe ... codePrefix="TB-" />`.
4. **Tile colours** — set `color` per category when you build `categories`
   (e.g. green if populated, orange if empty — see the example page). Omit to use
   the built-in palette.
5. **Legend label** — the bottom-left card says "Shipping from {hub}"; edit the
   text in `CategoryGlobe.jsx` (search `Shipping from`) if you want different wording.

## The map texture (`world.jpg`)

The renderer recolours the map **at runtime** into a flat 2-tone look: each pixel
is read, and ocean (where blue > green) is repainted bright blue, land golden.
So the supplied `world.jpg` is a simple equirectangular map; you can swap it for
any equirectangular world image and the recolour still applies. The blue/gold
target colours are `OCEAN_COLOR` / `LAND_COLOR` near the top of the file. Keep the
file at `public/world.jpg` or update `mapSrc`.

## SSR note (important)

The renderer touches `window`/`document`, so it must not be server-rendered.
That's already handled: `NetworkGlobe.tsx` lazy-imports it with
`dynamic(() => import('@/components/CategoryGlobe'), { ssr: false })`. Always
mount the globe through `NetworkGlobe` (a Client Component), never import
`CategoryGlobe` directly into a Server Component.

## Optional: hiding the site footer on this page

In ASTSPARES the globe page is full-screen with the footer hidden. That was a
separate one-liner (a `ConditionalFooter` that returns `null` on `/network`) and
is **not** included here — add it in your own layout if you want the same.
